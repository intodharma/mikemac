export async function getVerseText(reference: string, translation: string) {
  const encoded = encodeURIComponent(reference);

  try {
    const response = await fetch(`https://bible-api.com/${encoded}?translation=${translation.toLowerCase()}`);
    if (!response.ok) throw new Error('Verse request failed');
    const data = await response.json();
    return data.text || 'Verse text unavailable.';
  } catch {
    return 'Live verse text could not be loaded right now. Keep the provider pluggable here so you can swap in your preferred licensed translation source later.';
  }
}
