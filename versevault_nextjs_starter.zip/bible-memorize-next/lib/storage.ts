export type SavedState = {
  memorizing: string[];
  mastered: string[];
  streak: number;
  lastPracticedOn: string | null;
};

export const defaultState: SavedState = {
  memorizing: [],
  mastered: [],
  streak: 0,
  lastPracticedOn: null,
};

export function loadState(): SavedState {
  if (typeof window === 'undefined') return defaultState;
  const raw = window.localStorage.getItem('versevault-state');
  if (!raw) return defaultState;

  try {
    return { ...defaultState, ...JSON.parse(raw) } as SavedState;
  } catch {
    return defaultState;
  }
}

export function saveState(state: SavedState) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem('versevault-state', JSON.stringify(state));
}
