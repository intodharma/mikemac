import type { Config } from 'tailwindcss';

export default {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './lib/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        ink: '#e7eefc',
        mist: '#9fb1d9',
        glass: 'rgba(255,255,255,0.08)',
        line: 'rgba(255,255,255,0.12)',
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(255,255,255,0.12), 0 24px 80px rgba(0,0,0,0.35)',
      },
      backgroundImage: {
        'hero-gradient': 'radial-gradient(circle at top, rgba(110,130,255,0.22), transparent 32%), radial-gradient(circle at right, rgba(35,211,196,0.14), transparent 28%), linear-gradient(135deg, #07111f 0%, #0b1730 46%, #131a34 100%)',
      },
    },
  },
  plugins: [],
} satisfies Config;
