# VerseVault

A premium starter for a Bible verse memorization app.

## What is included
- Next.js 15 app router structure
- Tailwind glassmorphism UI
- Topic search
- Popular topic buttons
- Memorization mode
- Hide/reveal flow
- Typing practice area
- LocalStorage for memorizing/mastered/streaks
- Pluggable live verse provider

## Start it locally
```bash
npm install
npm run dev
```

## Deploy to Vercel
1. Push this folder to GitHub
2. Import the repo into Vercel
3. Deploy with default settings

## Important note on translations
This starter uses a pluggable verse provider. Some translations require licensed or approved APIs. Swap the provider in `lib/verse-provider.ts` to match the source you want to use.
