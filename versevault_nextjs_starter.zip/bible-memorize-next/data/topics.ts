export type VerseRef = {
  reference: string;
  topic: string;
  sampleText: string;
};

export const topics: Record<string, VerseRef[]> = {
  fear: [
    { reference: 'Isaiah 41:10', topic: 'Fear', sampleText: 'Fear not, for I am with you; be not dismayed, for I am your God...' },
    { reference: '2 Timothy 1:7', topic: 'Fear', sampleText: 'For God gave us a spirit not of fear but of power and love and self-control.' },
    { reference: 'Psalm 56:3', topic: 'Fear', sampleText: 'When I am afraid, I put my trust in you.' },
    { reference: 'Joshua 1:9', topic: 'Fear', sampleText: 'Be strong and courageous. Do not be frightened...' },
    { reference: 'Psalm 34:4', topic: 'Fear', sampleText: 'I sought the Lord, and he answered me and delivered me from all my fears.' },
    { reference: 'John 14:27', topic: 'Fear', sampleText: 'Let not your hearts be troubled, neither let them be afraid.' }
  ],
  love: [
    { reference: '1 Corinthians 13:4-7', topic: 'Love', sampleText: 'Love is patient and kind; love does not envy or boast...' },
    { reference: 'John 3:16', topic: 'Love', sampleText: 'For God so loved the world, that he gave his only Son...' },
    { reference: 'Romans 8:38-39', topic: 'Love', sampleText: 'Nothing will be able to separate us from the love of God...' },
    { reference: '1 John 4:19', topic: 'Love', sampleText: 'We love because he first loved us.' },
    { reference: 'Ephesians 3:17-19', topic: 'Love', sampleText: 'That you, being rooted and grounded in love, may have strength...' },
    { reference: 'Colossians 3:14', topic: 'Love', sampleText: 'Above all these put on love, which binds everything together in perfect harmony.' }
  ],
  anxiety: [
    { reference: 'Philippians 4:6-7', topic: 'Anxiety', sampleText: 'Do not be anxious about anything, but in everything by prayer...' },
    { reference: '1 Peter 5:7', topic: 'Anxiety', sampleText: 'Casting all your anxieties on him, because he cares for you.' },
    { reference: 'Matthew 6:34', topic: 'Anxiety', sampleText: 'Do not worry about tomorrow, for tomorrow will worry about itself.' },
    { reference: 'Psalm 94:19', topic: 'Anxiety', sampleText: 'When the cares of my heart are many, your consolations cheer my soul.' },
    { reference: 'Isaiah 26:3', topic: 'Anxiety', sampleText: 'You keep him in perfect peace whose mind is stayed on you...' },
    { reference: 'John 16:33', topic: 'Anxiety', sampleText: 'In the world you will have tribulation. But take heart; I have overcome the world.' }
  ],
  wisdom: [
    { reference: 'James 1:5', topic: 'Wisdom', sampleText: 'If any of you lacks wisdom, let him ask God...' },
    { reference: 'Proverbs 3:5-6', topic: 'Wisdom', sampleText: 'Trust in the Lord with all your heart...' },
    { reference: 'Proverbs 9:10', topic: 'Wisdom', sampleText: 'The fear of the Lord is the beginning of wisdom...' },
    { reference: 'Ecclesiastes 7:12', topic: 'Wisdom', sampleText: 'Wisdom preserves the life of him who has it.' },
    { reference: 'Colossians 2:3', topic: 'Wisdom', sampleText: 'In Christ are hidden all the treasures of wisdom and knowledge.' },
    { reference: 'Psalm 111:10', topic: 'Wisdom', sampleText: 'The fear of the Lord is the beginning of wisdom...' }
  ],
  strength: [
    { reference: 'Philippians 4:13', topic: 'Strength', sampleText: 'I can do all things through him who strengthens me.' },
    { reference: 'Isaiah 40:31', topic: 'Strength', sampleText: 'They who wait for the Lord shall renew their strength...' },
    { reference: 'Psalm 28:7', topic: 'Strength', sampleText: 'The Lord is my strength and my shield...' },
    { reference: 'Nehemiah 8:10', topic: 'Strength', sampleText: 'The joy of the Lord is your strength.' },
    { reference: 'Exodus 15:2', topic: 'Strength', sampleText: 'The Lord is my strength and my song...' },
    { reference: '2 Corinthians 12:9', topic: 'Strength', sampleText: 'My grace is sufficient for you, for my power is made perfect in weakness.' }
  ]
};

export const popularTopics = Object.keys(topics);
