import { VerseVaultApp } from '@/components/verse-vault-app';

export default function HomePage() {
  return <VerseVaultApp />;
}
