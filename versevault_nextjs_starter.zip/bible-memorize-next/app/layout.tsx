import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'VerseVault',
  description: 'A premium Bible verse memorization app organized by topic.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
